package com.example.inventorycontrolapplication.ui.help;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.example.inventorycontrolapplication.R;

import ir.drax.constraintaccordionlist.AccordionItem;
import ir.drax.constraintaccordionlist.AccordionList;

public class HelpFragment extends Fragment {

    private HelpViewModel helpViewModel;

    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Create the view model
        helpViewModel = new ViewModelProvider(this).get(HelpViewModel.class);
        View root = inflater.inflate(R.layout.fragment_help, container, false);

        // Create the help accordians
        AccordionList accordionList = root.findViewById(R.id.accordion);
        accordionList
                .setARROW_ICON(R.drawable.left_chevron)
                .push(new AccordionItem("How to add items to the list?", "Add items by hitting the plus button on the home screen and insert the name, type and count data. Hitting submit will add the item."))
                .push(new AccordionItem("How to change the product count?", "To change the product count start by clicking on the item count you need to be edit. Input the new count and hit submit. The count will be updated then"))
                .push(new AccordionItem("How to delete a product from the list?", "To delete a item tap the delete button."))
                .push(new AccordionItem("Can a registered username be reused?", "A username can only be registered once."))
                .build();
        return root;
    }
}
